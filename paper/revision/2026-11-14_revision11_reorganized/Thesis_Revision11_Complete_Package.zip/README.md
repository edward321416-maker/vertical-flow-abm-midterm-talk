# Thesis Revision 11: 본문 재구성 및 부록 분리

**판정:** 결론 뒤 A--J 부록 제거와 필수 방법·분석 설명의 본문 통합 완료. 연구의 실험 수치와 그림·표는 보존하면서 상세 재현 자료를 별도 PDF로 분리했다.

## 파일

- `Thesis_Revision11_Reorganized_Main_6pages.pdf` — 개정 본문 (A4, 2단, **6쪽**, 마지막이 참고문헌)
- `Thesis_Revision11_Technical_Supplement_3pages.pdf` — 별도 재현성·상세 집계 자료 3쪽
- `Thesis_Revision11_Editorial_QA_2pages.pdf` — 부록별 처리와 수정 근거·검수 판정 2쪽
- `source/Thesis_Revision11_Main.tex` — LaTeX 편집 원본
- `source/Thesis_Revision11_Supplement.tex` — 보충자료 원본
- `source/Revision10_to_Revision11_Main.patch` — 원본 Revision 10과의 unified diff
- `source/Revision11_Edit_Plan_and_Audit.md` — 편집 계획과 검수 근거
- `figures/` — 논문 속 도판 7개

## 분량과 서식의 중요한 구분

기존 Revision 10 8쪽판의 부록을 재배치하고 중복된 설명을 제거한 결과 본문은 자연스럽게 **6쪽**이 됐다. 대한건축학회 일반 논문작성지침의 6--12쪽 범위지만, 사용자의 예전 **정확히 8쪽** 작업조건과는 일치하지 않는다. 학교나 지도교수가 별도의 8쪽 고정 요건을 명시했다면 최종본으로 확정해서는 안 된다. 불필요한 문장·행간 확대를 통해 페이지를 부풀리는 방식은 채택하지 않았다.

본문은 공개 HWP에서 확인한 A4, 본문 9pt, 13.5pt 행간, 좌·우 16mm, 두 단 폭 각 84mm·간격 10mm를 기준으로 조판했고 원본 지정 휴먼명조 글꼴이 아닌 대체 서체를 사용한다. 공식 한/글 원본과 픽셀 일치를 보증하지 않는다.

## 연구·수치 근거

Revision 10의 실제 TeX 원고와 시뮬레이션 사전 동결 계획서/ODD/CSV를 비교했다. 저장 산출물의 내부 정합성과 주요 수치에 대한 검수이지, 실제 보행자 현장검증이나 전체 2,600회 독립 재실행이 아니다.

기준 소스 커밋: `ee4ea3255afbc359d0924a81b98de01c94281322` (edward321416-maker/vertical-flow-abm-midterm-talk).
